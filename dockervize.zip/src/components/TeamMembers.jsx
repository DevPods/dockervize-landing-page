import React from 'react';
import logo from '../assets/wordpressTransparent.png';

const TeamMembers = () => {
  return <img src={logo} alt='logo' />;
};

export default TeamMembers;
