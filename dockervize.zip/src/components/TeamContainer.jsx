import React from 'react';
import TeamMembers from './TeamMembers.jsx';

const TeamContainer = () => {


  return(
    <div>
      <TeamMembers />
    </div>
  );



};

export default TeamContainer;