import React from 'react';
import Header from './Header.jsx';

const ProductContainer = () => {


  return(
    <div>
      <Header/>
    </div>
  );



};

export default ProductContainer;