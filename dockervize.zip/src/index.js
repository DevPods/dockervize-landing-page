import React from 'react';
import ReactDOM from 'react-dom';
import App from '../src/app.jsx';
import '../src/style.css';
import '../src/style.scss';




ReactDOM.render(
  <App />,
  document.getElementById('root')
);