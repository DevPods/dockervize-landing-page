// import { createContext } from 'react/cjs/react.production.min';

// export const currLetterContext = createContext(null);